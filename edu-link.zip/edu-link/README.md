# Edu Link

A mobile-first school community app for secondary schools in Saint Vincent and the Grenadines. Built for the theme "Using Technology for a Better World".

Edu Link connects students, teachers and administrators. Its main feature, **EcoLink**, lets students report environmental problems and follow each report through a **Garbage-to-Action Tracker** until staff resolve it.

> **Prototype status:** this is a front-end prototype. All data is fictional demo data held in memory and resets on refresh. Nothing here is real school data or real impact results.

## Features

- Role-based access: student, teacher, administrator
- Email and password log in, first-login password change, admin-created accounts and password resets (no public sign-up)
- Announcements, events, academic resources, student activities, Lost & Found, suggestions, notifications, profile, global search
- School Calendar with Day, Week, Month, Year and Events views; teachers and admins can edit dates and upload the yearly calendar file
- EcoLink: dashboard, issue reporting, Garbage-to-Action Tracker, waste sorting guide, eco-events, eco-challenges, tips, staff review
- Privacy by design: no public student profiles, no student messaging, general locations only

## Run it

You need [Node.js](https://nodejs.org) 18 or newer.

```bash
npm install
npm run dev
```

Open the address shown in the terminal. To create a production build, run `npm run build`.

## Demo accounts (fictional)

| Role | Email | Password |
|------|-------|----------|
| Student | kemar@edulink.demo | Student#2026 |
| Teacher | ms.providence@edulink.demo | Teacher#2026 |
| Administrator | mr.dougan@edulink.demo | Admin#2026 |

The student account must choose a new password at first log in.

## Project layout

```
index.html        page shell
main.jsx          app entry point
App.jsx           the whole app (components, demo data)
index.css         Tailwind setup
```

The project is kept flat so it can be uploaded to GitHub from a phone. As the app grows, split `App.jsx` into folders (`components/`, `pages/`, `data/`).

## Put it on GitHub

1. Create a new repository on github.com.
2. Upload all files from this project (Add file, then Upload files).
3. Commit.

## Put it online (free)

1. Sign in to [Vercel](https://vercel.com) or [Netlify](https://netlify.com) with your GitHub account.
2. Import the `edu-link` repository.
3. Use the defaults: build command `npm run build`, output folder `dist`.
4. Deploy and share the link.

## Connecting a real backend

The prototype keeps data in React state. To make it real:

1. Create a [Supabase](https://supabase.com) or Firebase project.
2. Replace the demo `ACCOUNTS` list with Supabase Auth. Passwords must be hashed by the auth service. Keep accounts school-issued.
3. Create tables matching the data in `App.jsx`: users (with role), announcements, events, calendar entries, resources, activities, lost_found_items, eco_reports, eco_report_updates, eco_challenges, challenge_participation, suggestions, notifications, saved_resources.
4. Turn on row-level security so students see only their own reports, suggestions and notifications, and only teachers and admins can change announcements, events, the calendar and report statuses. The server must enforce roles; hiding buttons is not enough.
5. Store uploads (photos, the calendar file) in private storage with file type and size limits.
6. Add Google sign-in through the auth service, limited to school-approved accounts.
7. Never put private service keys in client code.

## Limits of this prototype

- Data and uploaded files reset on refresh.
- Photo upload and resource file links are placeholders.
- Passwords are stored in plain text in memory for the demo only.
- "Sign in with Google" and "Remember me" are display-only.
- No push notifications; notifications are in-app.
- Sample statistics are demo data, not real results.
