# Edu Link: 7-minute demo guide

Focus on working features. Keep to the prototype; do not claim real-world results.

| Time | What to show | What to say |
|------|--------------|-------------|
| 0:00 | Title and logo | The problem: school information is scattered, and students have no clear way to report environmental problems or see what was done. |
| 0:30 | Log in as the student, set a new password | Accounts are issued by the school. No public sign-up, because users are minors. |
| 1:15 | Home dashboard | One place for announcements, events and EcoLink. |
| 1:45 | Academic Resources: search, filter, save a favourite | Teacher-approved materials, easy to find. |
| 2:30 | School Calendar: Month view, tap a day | The school year in one view. |
| 3:00 | EcoLink: submit a report | A student spots an overflowing bin and reports it with a general location. |
| 3:45 | Open the Garbage-to-Action Tracker | Six steps from submission to resolved. |
| 4:15 | Sign out, log in as the teacher, EcoLink Review | Staff review it, assign it, and add an update. |
| 5:00 | Log back in as the student | The student sees the status change and the notification. |
| 5:30 | Waste sorting guide, eco-events, eco-challenges | Education and participation, all supervised. |
| 6:15 | Admin: create an account, reset a password, change a role | The school controls access. |
| 6:45 | Privacy and next steps | No public profiles, no student messaging, role-based access. Next: real backend, photo upload, more schools. |

Tips: rehearse with the three demo accounts first, and remember that data resets on refresh, so do the student, teacher, student sequence in one sitting.
