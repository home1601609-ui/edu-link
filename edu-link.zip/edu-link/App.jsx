import { useState, useMemo } from "react";
import {
  Home, Megaphone, CalendarDays, BookOpen, Users, Search as SearchIcon, Leaf, Lightbulb, Bell, User,
  ShieldCheck, Menu, X, Plus, Trash2, Star, Check, ChevronRight, LogOut, Recycle, Trophy, Package, Eye, EyeOff,
} from "lucide-react";

const C = { navy: "#14284B", teal: "#0B7F86", green: "#2F8F4E", light: "#F3F6F8", text: "#2B3340", mint: "#E4F3EA" };
const TODAY = new Date("2026-09-30");
const fmt = (d) => new Date(d).toLocaleDateString("en-GB", { day: "numeric", month: "short" });
const uid = () => Math.random().toString(36).slice(2, 9);

const Logo = ({ size = 36 }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" role="img" aria-label="Edu Link logo">
    <rect width="48" height="48" rx="12" fill={C.navy} />
    <path d="M10 30 Q17 26 24 30 Q31 26 38 30 L38 35 Q31 31 24 35 Q17 31 10 35Z" fill="#fff" />
    <circle cx="14" cy="17" r="3" fill={C.teal} /><circle cx="24" cy="12" r="3" fill={C.teal} /><circle cx="34" cy="17" r="3" fill={C.teal} />
    <path d="M14 17 L24 12 L34 17" stroke={C.teal} strokeWidth="1.5" fill="none" />
    <path d="M24 26 Q30 20 36 22 Q34 28 24 26Z" fill="#5FC27E" />
  </svg>
);

const USERS = [
  { id: "s1", name: "Kemar", role: "student", year: "Form 4B" },
  { id: "t1", name: "Ms. Providence", role: "teacher", year: "Staff" },
  { id: "a1", name: "Mr. Dougan", role: "admin", year: "Administration" },
];

const seed = {
  announcements: [
    { id: "an1", title: "Mid-term exams begin Monday", cat: "Academic", body: "Mid-term exams start Monday 5 October. Timetables are posted outside the main office. Arrive 15 minutes early.", date: "2026-09-29", by: "Administrator", priority: "Important", read: false },
    { id: "an2", title: "Inter-house athletics trials", cat: "Sports", body: "Trials for the 100m, 200m and relays are on Thursday after school at the playing field. Bring water and suitable footwear.", date: "2026-09-28", by: "Teacher", priority: "", read: false },
    { id: "an3", title: "Recycling bins now in every block", cat: "Environmental", body: "New colour-coded bins have been placed in each block. Check the EcoLink sorting guide before you toss.", date: "2026-09-26", by: "Teacher", priority: "", read: true },
    { id: "an4", title: "Coding Club sign-ups open", cat: "Clubs", body: "Coding Club meets Wednesdays in the IT lab. Ask the IT teacher to add your name.", date: "2026-09-24", by: "Teacher", priority: "", read: true },
  ],
  events: [
    { id: "ev1", title: "Staff and student assembly", cat: "School meetings", date: "2026-10-02", time: "8:30–9:15", place: "School hall", body: "Term updates and awards.", by: "Administration", interested: false, cancelled: false },
    { id: "ev2", title: "Inter-house athletics", cat: "Sports", date: "2026-10-09", time: "9:00–15:00", place: "Playing field", body: "Track and field day for all houses.", by: "Sports department", interested: false, cancelled: false },
    { id: "ev3", title: "Careers and culture fair", cat: "Cultural", date: "2026-10-16", time: "10:00–13:00", place: "Quadrangle", body: "Local businesses and cultural groups showcase.", by: "Guidance office", interested: false, cancelled: false },
  ],
  resources: [
    { id: "r1", title: "Quadratic equations revision guide", subject: "Mathematics", topic: "Algebra", type: "Revision guide", by: "Mr. Hadley", date: "2026-09-20", fav: false },
    { id: "r2", title: "Photosynthesis worksheet", subject: "Biology", topic: "Plants", type: "Worksheet", by: "Ms. Providence", date: "2026-09-22", fav: false },
    { id: "r3", title: "Essay structure summary", subject: "English Language", topic: "Writing", type: "Study summary", by: "Mrs. Samuel", date: "2026-09-15", fav: false },
    { id: "r4", title: "Spreadsheet formulas practice", subject: "Information Technology", topic: "Spreadsheets", type: "Practice questions", by: "Mr. Cato", date: "2026-09-25", fav: false },
    { id: "r5", title: "Caribbean rivers and watersheds", subject: "Geography", topic: "Physical geography", type: "PDF notes", by: "Ms. Ollivierre", date: "2026-09-18", fav: false },
    { id: "r6", title: "Verbes au présent", subject: "French", topic: "Grammar", type: "Worksheet", by: "Mme. Joseph", date: "2026-09-27", fav: false },
  ],
  activities: [
    { id: "ac1", name: "Coding Club", cat: "Academic competitions", body: "Build small apps and prepare for the national coding competition.", when: "Wednesdays, 3:30 pm, IT lab", staff: "IT teacher", interested: false },
    { id: "ac2", name: "Track and Field Squad", cat: "Sports", body: "Sprint, jump and throw training for inter-school meets.", when: "Tue and Thu, 3:30 pm, Playing field", staff: "Sports coordinator", interested: false },
    { id: "ac3", name: "Art and Culture Society", cat: "Arts and culture", body: "Painting, drama and folk music projects.", when: "Fridays, 1:00 pm, Art room", staff: "Art teacher", interested: false },
    { id: "ac4", name: "Green Team", cat: "Environmental", body: "Supervised clean-ups, tree planting and recycling drives.", when: "Mondays, 1:00 pm, Science block", staff: "Science teacher", interested: false },
  ],
  lostfound: [
    { id: "lf1", type: "Lost", title: "Blue water bottle", cat: "Personal items", place: "Near the canteen", date: "2026-09-28", body: "Dented lid, sticker on the side.", status: "Open" },
    { id: "lf2", type: "Found", title: "Calculator", cat: "Stationery", place: "Library", date: "2026-09-29", body: "Scientific calculator. Collect from the main office with proof.", status: "Open" },
  ],
  reports: [
    { id: "er1", by: "s1", title: "Overflowing bin at the canteen", cat: "Overflowing garbage bins", place: "Canteen", body: "Bin is full by lunchtime and litter blows around.", date: "2026-09-22", status: "In Progress", assigned: "Caretaker", updates: [{ status: "Under Review", msg: "Received and being checked.", date: "2026-09-23" }, { status: "In Progress", msg: "Extra bin ordered; caretaker will empty it at lunch.", date: "2026-09-25" }] },
    { id: "er2", by: "s9", title: "Blocked drain by Block C", cat: "Blocked drains", place: "Block C", body: "Water pools after rain.", date: "2026-09-18", status: "Resolved", assigned: "Caretaker", updates: [{ status: "Resolved", msg: "Drain cleared and checked after rain.", date: "2026-09-24" }] },
    { id: "er3", by: "s1", title: "Litter along the back fence", cat: "Littering", place: "Back fence", body: "Plastic bottles and wrappers.", date: "2026-09-29", status: "Pending", assigned: "", updates: [] },
  ],
  ecoEvents: [
    { id: "ee1", title: "School clean-up day", date: "2026-10-10", place: "Meet at the quadrangle", body: "Supervised clean-up of the grounds. Gloves provided.", by: "Green Team", how: "Sign up with your form teacher.", interested: false },
    { id: "ee2", title: "Tree-planting morning", date: "2026-10-24", place: "Back field", body: "Plant fruit trees with staff guidance.", by: "Science department", how: "Wear old clothes and closed shoes.", interested: false },
  ],
  challenges: [
    { id: "ch1", title: "Bring a reusable bottle", body: "Use a reusable bottle at school for 5 days.", start: "2026-09-28", end: "2026-10-09", goal: 5, progress: 2, joined: true },
    { id: "ch2", title: "Sort it right", body: "Use the sorting guide and sort your lunch waste correctly for a week.", start: "2026-09-28", end: "2026-10-12", goal: 5, progress: 0, joined: false },
    { id: "ch3", title: "Tidy classroom", body: "Keep your classroom litter-free at the end of every day.", start: "2026-09-21", end: "2026-10-02", goal: 10, progress: 7, joined: true },
  ],
  suggestions: [
    { id: "sg1", by: "s1", title: "More charging points in the library", cat: "Technology", body: "Students often run out of battery while doing research.", status: "In Discussion", reply: "Facilities is checking what the wiring can support.", date: "2026-09-20" },
  ],
  notifications: [
    { id: "n1", to: "s1", title: "Report update", msg: "Your canteen bin report is now In Progress.", page: "eco", read: false, date: "2026-09-25" },
    { id: "n2", to: "s1", title: "New announcement", msg: "Mid-term exams begin Monday.", page: "announcements", read: false, date: "2026-09-29" },
    { id: "n3", to: "s1", title: "Suggestion response", msg: "Staff replied to your library suggestion.", page: "suggestions", read: true, date: "2026-09-26" },
  ],
};

const CAL_TYPES = ["Term", "Holiday", "Exam", "Event", "Other"];
const CAL_COLOR = { Term: C.navy, Holiday: C.green, Exam: "#B3261E", Event: C.teal, Other: "#6B7280" };
const CAL_SEED = [
  { id: "c1", title: "Term 1 begins (sample)", type: "Term", start: "2026-09-07", end: "" },
  { id: "c2", title: "Mid-term exams (sample)", type: "Exam", start: "2026-10-05", end: "2026-10-09" },
  { id: "c3", title: "Mid-term break (sample)", type: "Holiday", start: "2026-10-26", end: "2026-10-30" },
  { id: "c4", title: "Term 1 ends (sample)", type: "Term", start: "2026-12-11", end: "" },
];
const ACCOUNTS = [
  { id: "s1", username: "kemar@edulink.demo", password: "Student#2026", name: "Kemar", role: "student", year: "Form 4B", mustChange: true },
  { id: "t1", username: "ms.providence@edulink.demo", password: "Teacher#2026", name: "Ms. Providence", role: "teacher", year: "Staff", mustChange: false },
  { id: "a1", username: "mr.dougan@edulink.demo", password: "Admin#2026", name: "Mr. Dougan", role: "admin", year: "Administration", mustChange: false },
];
const pwProblem = (pw, username, current) => {
  if (pw.length < 8) return "Use at least 8 characters.";
  if (!/\d/.test(pw) || !/[A-Za-z]/.test(pw)) return "Include at least one letter and one number.";
  if (pw === current) return "Choose a different password from your current one.";
  if (pw.toLowerCase().includes(username.split("@")[0])) return "Do not use your name or email in your password.";
  return "";
};
const SORT = [
  { item: "plastic bottle", bin: "Recyclable", why: "Rinse, crush and place in the recycling bin." },
  { item: "aluminium can", bin: "Recyclable", why: "Metal can be melted and reused many times." },
  { item: "paper", bin: "Recyclable", why: "Keep it dry and clean so it can be recycled." },
  { item: "banana peel", bin: "Organic", why: "Compost it. It breaks down into soil." },
  { item: "fruit scraps", bin: "Organic", why: "Food scraps belong in compost, not with plastics." },
  { item: "chip bag", bin: "General waste", why: "Mixed-material wrappers usually cannot be recycled." },
  { item: "styrofoam", bin: "General waste", why: "Hard to recycle locally; avoid where you can." },
  { item: "battery", bin: "Special disposal", why: "Batteries leak harmful chemicals. Hand them to a teacher." },
  { item: "broken glass", bin: "Special disposal", why: "Do not touch. Tell a teacher or the caretaker." },
];
const TIPS = [
  "Clear leaves from drains before the rainy season to prevent flooding.",
  "Carry a reusable bottle. It cuts single-use plastic at school.",
  "Turn off fans and lights when you leave a room.",
  "Never feed or litter near wildlife areas; food wrappers harm animals.",
  "Close taps fully. A dripping tap wastes many litres a week.",
];
const STEPS = ["Report submitted", "Received by school", "Staff review", "Assigned for action", "Issue addressed", "Resolved after review"];
const STEP_OF = { Pending: 2, "Under Review": 3, Approved: 4, "In Progress": 5, Resolved: 6, Rejected: 3 };
const ECO_STATUSES = ["Pending", "Under Review", "Approved", "In Progress", "Resolved", "Rejected"];
const SG_STATUSES = ["Submitted", "Under Review", "In Discussion", "Accepted", "Not Accepted", "Completed"];

const Card = ({ children, className = "", onClick }) => (
  <div onClick={onClick} className={"bg-white rounded-2xl p-4 shadow-sm border border-gray-100 " + className}>{children}</div>
);
const Btn = ({ children, onClick, kind = "primary", className = "", type = "button" }) => {
  const bg = kind === "primary" ? C.navy : kind === "eco" ? C.green : kind === "danger" ? "#B3261E" : "#fff";
  return (
    <button type={type} onClick={onClick} style={{ background: bg, color: kind === "ghost" ? C.navy : "#fff", borderColor: C.navy }}
      className={"rounded-xl px-4 py-3 text-sm font-semibold min-h-11 " + (kind === "ghost" ? "border " : "") + className}>{children}</button>
  );
};
const Badge = ({ children, color = C.teal }) => (
  <span className="text-xs font-semibold rounded-full px-2 py-1" style={{ background: color + "22", color }}>{children}</span>
);
const statusColor = (s) => ({ Pending: "#8A6D00", "Under Review": C.teal, Approved: C.navy, "In Progress": "#B45309", Resolved: C.green, Rejected: "#B3261E" }[s] || C.teal);
const Field = ({ label, error, children }) => (
  <label className="block mb-3">
    <span className="block text-sm font-semibold mb-1" style={{ color: C.navy }}>{label}</span>
    {children}
    {error && <span role="alert" className="block text-sm mt-1" style={{ color: "#B3261E" }}>{error}</span>}
  </label>
);
const inputCls = "w-full border border-gray-300 rounded-xl px-3 py-3 text-base bg-white";
const Empty = ({ text }) => <div className="text-center text-gray-500 py-10 text-sm">{text}</div>;
const Title = ({ children, right }) => (
  <div className="flex items-center justify-between mb-3"><h2 className="text-xl font-bold" style={{ color: C.navy }}>{children}</h2>{right}</div>
);
const Demo = () => <Badge color="#6B7280">Demo data</Badge>;

export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("home");
  const [sel, setSel] = useState(null);
  const [menu, setMenu] = useState(false);
  const [toast, setToast] = useState("");
  const [d, setD] = useState({ ...seed, calendar: CAL_SEED, calFile: null });
  const [tipIdx, setTipIdx] = useState(0);
  const [accounts, setAccounts] = useState(ACCOUNTS); const [pending, setPending] = useState(null);

  const say = (m) => { setToast(m); setTimeout(() => setToast(""), 2600); };
  const upd = (key, fn) => setD((p) => ({ ...p, [key]: fn(p[key]) }));
  const notify = (to, title, msg, pg) => upd("notifications", (n) => [{ id: uid(), to, title, msg, page: pg, read: false, date: "2026-09-30" }, ...n]);
  const go = (p, s = null) => { setPage(p); setSel(s); setMenu(false); window.scrollTo?.(0, 0); };
  const isStaff = user && user.role !== "student";
  const isAdmin = user && user.role === "admin";
  const ctx = { user, d, upd, say, go, sel, notify, isStaff, isAdmin, tipIdx, setTipIdx, accounts, setAccounts };

  const myNotes = d.notifications.filter((n) => n.to === user?.id);
  const unread = myNotes.filter((n) => !n.read).length;

  if (pending) return <ChangePassword account={pending} current={accounts.find((x) => x.id === pending.id).password} onCancel={() => setPending(null)}
    onDone={(pw) => { setAccounts((a) => a.map((x) => (x.id === pending.id ? { ...x, password: pw, mustChange: false } : x))); setUser({ ...pending, mustChange: false }); setPending(null); setPage("home"); }} />;
  if (!user) return <Login accounts={accounts} onLogin={(u) => { if (u.mustChange) setPending(u); else { setUser(u); setPage("home"); } }} />;

  const nav = [
    ["home", "Home", Home], ["announcements", "News", Megaphone], ["events", "Events", CalendarDays], ["eco", "EcoLink", Leaf],
  ];
  const more = [
    ["calendar", "School Calendar", CalendarDays], ["resources", "Academic Resources", BookOpen], ["activities", "Student Activities", Users], ["lostfound", "Lost & Found", Package],
    ["suggestions", "Suggestions", Lightbulb], ["notifications", "Notifications", Bell], ["search", "Search", SearchIcon], ["profile", "Profile", User],
    ...(isStaff ? [["admin", isAdmin ? "Admin Dashboard" : "Staff Dashboard", ShieldCheck]] : []),
  ];

  const pages = {
    home: <HomePage {...ctx} />, announcements: <Announcements {...ctx} />, events: <Events {...ctx} />, calendar: <SchoolCalendar {...ctx} />, resources: <Resources {...ctx} />,
    activities: <Activities {...ctx} />, lostfound: <LostFound {...ctx} />, eco: <Eco {...ctx} />, suggestions: <Suggestions {...ctx} />,
    notifications: <Notifications {...ctx} notes={myNotes} />, profile: <Profile {...ctx} onOut={() => setUser(null)} />,
    search: <GlobalSearch {...ctx} />, admin: isStaff ? <Admin {...ctx} /> : <Empty text="You do not have access to this page." />,
  };

  return (
    <div className="min-h-screen pb-24" style={{ background: C.light, color: C.text }}>
      <header className="sticky top-0 z-20 flex items-center gap-3 px-4 py-3 text-white" style={{ background: C.navy }}>
        <Logo size={32} />
        <button onClick={() => go("home")} className="font-bold text-lg flex-1 text-left">Edu Link</button>
        <button aria-label="Notifications" onClick={() => go("notifications")} className="relative p-2">
          <Bell size={22} />{unread > 0 && <span className="absolute top-0 right-0 text-xs rounded-full w-5 h-5 flex items-center justify-center" style={{ background: C.green }}>{unread}</span>}
        </button>
      </header>
      <main className="max-w-2xl mx-auto p-4">{pages[page]}</main>
      {toast && <div role="status" className="fixed bottom-24 left-1/2 -translate-x-1/2 z-40 px-4 py-3 rounded-xl text-white text-sm shadow-lg" style={{ background: C.teal }}>{toast}</div>}
      {menu && (
        <div className="fixed inset-0 z-30 bg-black bg-opacity-40" onClick={() => setMenu(false)}>
          <div className="absolute bottom-20 left-3 right-3 max-w-2xl mx-auto bg-white rounded-2xl p-3" onClick={(e) => e.stopPropagation()}>
            {more.map(([k, label, Ic]) => (
              <button key={k} onClick={() => go(k)} className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left">
                <Ic size={20} color={C.teal} /><span className="flex-1">{label}</span>{k === "notifications" && unread > 0 && <Badge color={C.green}>{unread}</Badge>}
              </button>
            ))}
          </div>
        </div>
      )}
      <nav className="fixed bottom-0 inset-x-0 z-30 bg-white border-t border-gray-200 flex" aria-label="Main">
        {nav.map(([k, label, Ic]) => (
          <button key={k} onClick={() => go(k)} className="flex-1 flex flex-col items-center py-2 min-h-14" style={{ color: page === k ? (k === "eco" ? C.green : C.navy) : "#6B7280" }}>
            <Ic size={22} /><span className="text-xs mt-1 font-semibold">{label}</span>
          </button>
        ))}
        <button onClick={() => setMenu(!menu)} className="flex-1 flex flex-col items-center py-2 min-h-14 text-gray-500">
          {menu ? <X size={22} /> : <Menu size={22} />}<span className="text-xs mt-1 font-semibold">More</span>
        </button>
      </nav>
    </div>
  );
}

function Login({ accounts, onLogin }) {
  const [u, setU] = useState(""); const [p, setP] = useState(""); const [show, setShow] = useState(false); const [remember, setRemember] = useState(false);
  const [err, setErr] = useState({}); const [fails, setFails] = useState(0); const [forgot, setForgot] = useState(false); const [demo, setDemo] = useState(false); const [gmsg, setGmsg] = useState(false);
  const locked = fails >= 5;
  const submit = () => {
    if (locked) return;
    const e = {}; if (!u.trim()) e.u = "Enter your email address."; else if (!/^\S+@\S+\.\S+$/.test(u.trim())) e.u = "Enter a valid email address."; if (!p) e.p = "Enter your password.";
    setErr(e); if (Object.keys(e).length) return;
    const acc = accounts.find((x) => x.username === u.trim().toLowerCase() && x.password === p);
    if (!acc) { const n = fails + 1; setFails(n); setErr({ form: n >= 5 ? "Too many attempts. Ask your teacher or administrator to reset your password." : "Incorrect email or password. " + (5 - n) + " attempt" + (5 - n === 1 ? "" : "s") + " left." }); return; }
    setFails(0); const { password, ...safe } = acc; onLogin(safe);
  };
  return (
    <div className="min-h-screen flex flex-col items-center p-5" style={{ background: "#fff" }}>
      <div className="w-full max-w-sm pt-8">
        <div className="flex flex-col items-center mb-6"><Logo size={64} /><p className="text-lg font-bold mt-2" style={{ color: C.navy }}>Edu Link</p></div>
        <h1 className="text-3xl font-bold text-center mb-5" style={{ color: C.text }}>Log In</h1>
        <input className={inputCls + " mb-1"} type="email" placeholder="Email Address" aria-label="Email address" value={u} autoComplete="username" autoCapitalize="none" onChange={(e) => setU(e.target.value)} disabled={locked} />
        {err.u && <p role="alert" className="text-sm mb-2" style={{ color: "#B3261E" }}>{err.u}</p>}
        <div className="relative mt-3 mb-1">
          <input className={inputCls} type={show ? "text" : "password"} placeholder="Password" aria-label="Password" value={p} autoComplete="current-password" onChange={(e) => setP(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit()} disabled={locked} />
          <button type="button" aria-label={show ? "Hide password" : "Show password"} onClick={() => setShow(!show)} className="absolute right-3 top-3 text-gray-500">{show ? <EyeOff size={22} /> : <Eye size={22} />}</button>
        </div>
        {err.p && <p role="alert" className="text-sm mb-2" style={{ color: "#B3261E" }}>{err.p}</p>}
        <label className="flex items-center gap-2 text-base my-4"><input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} className="w-5 h-5" />Remember me for 30 days</label>
        {err.form && <p role="alert" className="text-sm mb-3" style={{ color: "#B3261E" }}>{err.form}</p>}
        <Btn onClick={submit} className="w-full">Log In</Btn>
        <p className="text-center text-gray-500 my-2">or</p>
        <button type="button" onClick={() => setGmsg(true)} className="w-full border border-gray-300 rounded-xl py-3 text-base font-semibold flex items-center justify-center gap-3 min-h-11"><span className="font-bold text-xl" style={{ color: "#4285F4" }}>G</span>Sign in with Google</button>
        {gmsg && <p className="text-sm mt-2 p-3 rounded-xl" style={{ background: C.light }}>Google sign-in connects in the live version, limited to school-approved accounts. For now, log in with your school email and password.</p>}
        <button className="block mx-auto text-base text-gray-600 mt-5" onClick={() => setForgot(!forgot)}>Forgot your password?</button>
        {forgot && <p className="text-sm mt-2 p-3 rounded-xl" style={{ background: C.light }}>Ask your teacher or school administrator to reset it. They will give you a temporary password, and you will choose a new one when you log in.</p>}
        <div className="mt-6 border-t border-gray-200 pt-3">
          <button className="w-full flex items-center justify-between text-sm font-semibold" style={{ color: C.navy }} onClick={() => setDemo(!demo)}>Demo logins (fictional)<ChevronRight size={18} style={{ transform: demo ? "rotate(90deg)" : "none" }} /></button>
          {demo && <div className="mt-2">{ACCOUNTS.map((a) => <button key={a.id} onClick={() => { setU(a.username); setP(a.password); setErr({}); }} className="w-full text-left text-sm border border-gray-200 rounded-xl p-2 mb-2">
            <b className="capitalize">{a.role === "admin" ? "Administrator" : a.role}</b> · {a.username} · {a.password}</button>)}
            <p className="text-xs text-gray-500">Tap one to fill the form. The student account must set a new password at first log in.</p></div>}
        </div>
        <p className="text-xs text-center text-gray-500 mt-4">Accounts are created by your school. There is no public sign-up.</p>
      </div>
    </div>
  );
}

function ChangePassword({ account, current, onDone, onCancel }) {
  const [a, setA] = useState(""); const [b, setB] = useState(""); const [err, setErr] = useState("");
  const submit = () => { const prob = pwProblem(a, account.username, current); if (prob) return setErr(prob); if (a !== b) return setErr("Passwords do not match."); onDone(a); };
  return (
    <div className="min-h-screen flex items-center justify-center p-5" style={{ background: C.navy }}>
      <div className="w-full max-w-sm"><Card>
        <h2 className="text-xl font-bold mb-1" style={{ color: C.navy }}>Choose a new password</h2>
        <p className="text-sm text-gray-500 mb-3">Welcome, {account.name}. Replace your temporary password before you continue.</p>
        <Field label="New password"><input type="password" className={inputCls} value={a} autoComplete="new-password" onChange={(e) => setA(e.target.value)} /></Field>
        <Field label="Confirm new password"><input type="password" className={inputCls} value={b} autoComplete="new-password" onChange={(e) => setB(e.target.value)} /></Field>
        <p className="text-xs text-gray-500 mb-3">At least 8 characters with a letter and a number.</p>
        {err && <p role="alert" className="text-sm mb-3" style={{ color: "#B3261E" }}>{err}</p>}
        <div className="flex gap-2"><Btn onClick={submit}>Save and continue</Btn><Btn kind="ghost" onClick={onCancel}>Cancel</Btn></div>
      </Card></div>
    </div>
  );
}

function ChangePw({ user, accounts, setAccounts, say }) {
  const [c, setC] = useState(""); const [a, setA] = useState(""); const [b, setB] = useState(""); const [err, setErr] = useState("");
  const me = accounts.find((x) => x.id === user.id);
  const submit = () => {
    if (!me || c !== me.password) return setErr("Your current password is incorrect.");
    const prob = pwProblem(a, me.username, me.password); if (prob) return setErr(prob); if (a !== b) return setErr("Passwords do not match.");
    setAccounts((x) => x.map((y) => (y.id === me.id ? { ...y, password: a } : y))); setC(""); setA(""); setB(""); setErr(""); say("Password changed");
  };
  return (
    <Card className="mb-3"><div className="font-semibold mb-2">Change password</div>
      <Field label="Current password"><input type="password" className={inputCls} value={c} autoComplete="current-password" onChange={(e) => setC(e.target.value)} /></Field>
      <Field label="New password"><input type="password" className={inputCls} value={a} autoComplete="new-password" onChange={(e) => setA(e.target.value)} /></Field>
      <Field label="Confirm new password"><input type="password" className={inputCls} value={b} autoComplete="new-password" onChange={(e) => setB(e.target.value)} /></Field>
      {err && <p role="alert" className="text-sm mb-2" style={{ color: "#B3261E" }}>{err}</p>}
      <Btn onClick={submit}>Update password</Btn></Card>
  );
}

function HomePage({ user, d, go, tipIdx }) {
  const mine = d.notifications.filter((n) => n.to === user.id).slice(0, 2);
  const shortcuts = [["announcements", "Announcements", Megaphone], ["events", "Events", CalendarDays], ["resources", "Resources", BookOpen], ["lostfound", "Lost & Found", Package], ["eco", "EcoLink", Leaf], ["suggestions", "Suggestions", Lightbulb]];
  const count = (s) => d.reports.filter((r) => r.status === s).length;
  return (
    <div>
      <div className="rounded-2xl p-5 text-white mb-4" style={{ background: C.teal }}>
        <p className="text-sm opacity-90">{TODAY.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</p>
        <h1 className="text-2xl font-bold mt-1">Good day, {user.name}</h1>
        <p className="text-sm mt-2 opacity-90">Small steps every day add up. Check what is new at school today.</p>
      </div>
      <div className="grid grid-cols-3 gap-3 mb-5">
        {shortcuts.map(([k, l, Ic]) => (
          <button key={k} onClick={() => go(k)} className="bg-white rounded-2xl py-4 flex flex-col items-center gap-2 border border-gray-100 min-h-24">
            <Ic size={26} color={k === "eco" ? C.green : C.navy} /><span className="text-xs font-semibold text-center">{l}</span>
          </button>
        ))}
      </div>
      <Title right={<button className="text-sm font-semibold" style={{ color: C.teal }} onClick={() => go("events")}>See all</button>}>Upcoming events</Title>
      {d.events.filter((e) => !e.cancelled).slice(0, 2).map((e) => (
        <Card key={e.id} className="mb-2"><div className="font-semibold">{e.title}</div><div className="text-sm text-gray-500">{fmt(e.date)} · {e.time} · {e.place}</div></Card>
      ))}
      <div className="h-4" />
      <Title right={<button className="text-sm font-semibold" style={{ color: C.teal }} onClick={() => go("announcements")}>See all</button>}>Latest announcements</Title>
      {d.announcements.slice(0, 2).map((a) => (
        <Card key={a.id} className="mb-2" onClick={() => go("announcements", a.id)}>
          <div className="flex gap-2 mb-1"><Badge>{a.cat}</Badge>{a.priority && <Badge color="#B3261E">{a.priority}</Badge>}</div>
          <div className="font-semibold">{a.title}</div><div className="text-sm text-gray-500">{a.body.slice(0, 70)}…</div>
        </Card>
      ))}
      <div className="h-4" />
      <div className="rounded-2xl p-4 border" style={{ background: C.mint, borderColor: "#BFE3CC" }}>
        <div className="flex items-center justify-between mb-2"><div className="flex items-center gap-2 font-bold" style={{ color: C.green }}><Leaf size={20} />EcoLink</div><Demo /></div>
        <p className="text-sm mb-3">{d.reports.length} reports · {count("Resolved")} resolved · {d.challenges.length} active challenges</p>
        <p className="text-sm italic mb-3">Tip: {TIPS[tipIdx % TIPS.length]}</p>
        <Btn kind="eco" onClick={() => go("eco")}>Report a cleanliness issue</Btn>
      </div>
      {mine.length > 0 && (<><div className="h-4" /><Title>Notifications</Title>
        {mine.map((n) => <Card key={n.id} className="mb-2" onClick={() => go(n.page)}><div className="font-semibold text-sm">{n.title}</div><div className="text-sm text-gray-500">{n.msg}</div></Card>)}</>)}
    </div>
  );
}

function Announcements({ d, upd, say, isStaff, sel, go, notify }) {
  const [q, setQ] = useState(""); const [cat, setCat] = useState("All"); const [form, setForm] = useState(null); const [err, setErr] = useState({});
  const cats = ["All", "General", "Academic", "Events", "Sports", "Clubs", "Environmental", "Important Notices"];
  const list = d.announcements.filter((a) => (cat === "All" || a.cat === cat) && (a.title + a.body).toLowerCase().includes(q.toLowerCase())).sort((a, b) => b.date.localeCompare(a.date));
  const open = d.announcements.find((a) => a.id === sel);
  const save = () => {
    const e = {}; if (form.title.trim().length < 4) e.title = "Enter a title of at least 4 characters."; if (form.body.trim().length < 10) e.body = "Enter at least 10 characters.";
    setErr(e); if (Object.keys(e).length) return;
    upd("announcements", (a) => [{ id: uid(), ...form, date: "2026-09-30", by: "Teacher", read: false }, ...a]);
    notify("s1", "New announcement", form.title, "announcements"); say("Announcement published"); setForm(null);
  };
  if (open) return (
    <div><button className="text-sm mb-3 font-semibold" style={{ color: C.teal }} onClick={() => go("announcements")}>Back to announcements</button>
      <Card><div className="flex gap-2 mb-2"><Badge>{open.cat}</Badge>{open.priority && <Badge color="#B3261E">{open.priority}</Badge>}</div>
        <h2 className="text-xl font-bold mb-1" style={{ color: C.navy }}>{open.title}</h2><p className="text-xs text-gray-500 mb-3">{fmt(open.date)} · Posted by {open.by}</p><p className="mb-4">{open.body}</p>
        <div className="flex gap-2">
          {!isStaff && <Btn kind={open.read ? "ghost" : "primary"} onClick={() => { upd("announcements", (a) => a.map((x) => x.id === open.id ? { ...x, read: !x.read } : x)); say(open.read ? "Marked as unread" : "Marked as read"); }}>{open.read ? "Mark as unread" : "Mark as read"}</Btn>}
          {isStaff && <Btn kind="danger" onClick={() => { upd("announcements", (a) => a.filter((x) => x.id !== open.id)); say("Announcement removed"); go("announcements"); }}>Remove</Btn>}
        </div></Card></div>
  );
  return (
    <div>
      <Title right={isStaff && <Btn onClick={() => setForm({ title: "", body: "", cat: "General", priority: "" })}><Plus size={16} className="inline" /> New</Btn>}>Announcements</Title>
      {form && (
        <Card className="mb-4"><Field label="Title" error={err.title}><input className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></Field>
          <Field label="Category"><select className={inputCls} value={form.cat} onChange={(e) => setForm({ ...form, cat: e.target.value })}>{cats.slice(1).map((c) => <option key={c}>{c}</option>)}</select></Field>
          <Field label="Message" error={err.body}><textarea className={inputCls} rows={3} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} /></Field>
          <div className="flex gap-2"><Btn onClick={save}>Publish</Btn><Btn kind="ghost" onClick={() => setForm(null)}>Cancel</Btn></div></Card>
      )}
      <input className={inputCls + " mb-3"} placeholder="Search announcements" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search announcements" />
      <div className="flex gap-2 overflow-x-auto pb-3">{cats.map((c) => <button key={c} onClick={() => setCat(c)} className="whitespace-nowrap rounded-full px-3 py-2 text-sm font-semibold border" style={{ background: cat === c ? C.navy : "#fff", color: cat === c ? "#fff" : C.navy, borderColor: C.navy }}>{c}</button>)}</div>
      {list.length === 0 ? <Empty text="No announcements match. Try another search or category." /> : list.map((a) => (
        <Card key={a.id} className="mb-2" onClick={() => go("announcements", a.id)}>
          <div className="flex gap-2 mb-1"><Badge>{a.cat}</Badge>{a.priority && <Badge color="#B3261E">{a.priority}</Badge>}{!a.read && !isStaff && <Badge color={C.green}>Unread</Badge>}</div>
          <div className="font-semibold">{a.title}</div><div className="text-sm text-gray-500">{fmt(a.date)} · {a.body.slice(0, 60)}…</div>
        </Card>
      ))}
    </div>
  );
}

function Events({ d, upd, say, isStaff }) {
  const [form, setForm] = useState(null); const [err, setErr] = useState({}); const [view, setView] = useState("list");
  const save = () => {
    const e = {}; if (form.title.trim().length < 4) e.title = "Enter a title."; if (!form.date) e.date = "Choose a date."; if (!form.place.trim()) e.place = "Enter a general location.";
    setErr(e); if (Object.keys(e).length) return;
    upd("events", (x) => [...x, { id: uid(), ...form, cat: "School meetings", by: "Staff", interested: false, cancelled: false }].sort((a, b) => a.date.localeCompare(b.date))); say("Event created"); setForm(null);
  };
  const days = [...Array(14)].map((_, i) => { const t = new Date(TODAY); t.setDate(t.getDate() + i); return t.toISOString().slice(0, 10); });
  return (
    <div>
      <Title right={isStaff && <Btn onClick={() => setForm({ title: "", date: "", time: "9:00–10:00", place: "", body: "" })}><Plus size={16} className="inline" /> New</Btn>}>Events</Title>
      {form && (<Card className="mb-4">
        <Field label="Title" error={err.title}><input className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></Field>
        <Field label="Date" error={err.date}><input type="date" className={inputCls} value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field>
        <Field label="General location" error={err.place}><input className={inputCls} value={form.place} onChange={(e) => setForm({ ...form, place: e.target.value })} /></Field>
        <div className="flex gap-2"><Btn onClick={save}>Create event</Btn><Btn kind="ghost" onClick={() => setForm(null)}>Cancel</Btn></div></Card>)}
      <div className="flex gap-2 mb-3">{["list", "calendar"].map((v) => <button key={v} onClick={() => setView(v)} className="rounded-full px-4 py-2 text-sm font-semibold border capitalize" style={{ background: view === v ? C.navy : "#fff", color: view === v ? "#fff" : C.navy, borderColor: C.navy }}>{v}</button>)}</div>
      {view === "calendar" && (<div className="grid grid-cols-7 gap-1 mb-4">{days.map((day) => { const has = d.events.some((e) => e.date === day && !e.cancelled); return <div key={day} className="rounded-lg text-center py-2 text-xs font-semibold" style={{ background: has ? C.teal : "#fff", color: has ? "#fff" : C.text }}>{new Date(day).getDate()}</div>; })}</div>)}
      {d.events.length === 0 && <Empty text="No upcoming events yet." />}
      {d.events.map((e) => (
        <Card key={e.id} className="mb-3">
          <div className="flex justify-between"><Badge>{e.cat}</Badge>{e.cancelled && <Badge color="#B3261E">Cancelled</Badge>}</div>
          <div className="font-semibold mt-1">{e.title}</div><div className="text-sm text-gray-500">{fmt(e.date)} · {e.time} · {e.place}</div><p className="text-sm mt-1 mb-3">{e.body}</p>
          <div className="flex gap-2">
            {!e.cancelled && !isStaff && <Btn kind={e.interested ? "ghost" : "primary"} onClick={() => { upd("events", (x) => x.map((y) => y.id === e.id ? { ...y, interested: !y.interested } : y)); say(e.interested ? "Interest removed" : "Marked as interested"); }}>{e.interested ? "Interested ✓" : "I'm interested"}</Btn>}
            {isStaff && !e.cancelled && <Btn kind="danger" onClick={() => { upd("events", (x) => x.map((y) => y.id === e.id ? { ...y, cancelled: true } : y)); say("Event cancelled"); }}>Cancel event</Btn>}
          </div>
        </Card>
      ))}
    </div>
  );
}

function Resources({ d, upd, say, isStaff }) {
  const [q, setQ] = useState(""); const [subj, setSubj] = useState("All"); const [favOnly, setFavOnly] = useState(false); const [form, setForm] = useState(null); const [err, setErr] = useState({});
  const subjects = ["All", "Mathematics", "English Language", "Biology", "Integrated Science", "Information Technology", "Social Studies", "History", "Geography", "French", "Spanish"];
  const list = d.resources.filter((r) => (subj === "All" || r.subject === subj) && (!favOnly || r.fav) && (r.title + r.topic).toLowerCase().includes(q.toLowerCase())).sort((a, b) => b.date.localeCompare(a.date));
  const save = () => { const e = {}; if (form.title.trim().length < 4) e.title = "Enter a title."; if (!form.topic.trim()) e.topic = "Enter a topic."; setErr(e); if (Object.keys(e).length) return;
    upd("resources", (r) => [{ id: uid(), ...form, by: "Teacher", date: "2026-09-30", fav: false }, ...r]); say("Resource added"); setForm(null); };
  return (
    <div>
      <Title right={isStaff && <Btn onClick={() => setForm({ title: "", subject: "Mathematics", topic: "", type: "Worksheet" })}><Plus size={16} className="inline" /> Add</Btn>}>Academic Resources</Title>
      {form && (<Card className="mb-4">
        <Field label="Title" error={err.title}><input className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></Field>
        <Field label="Subject"><select className={inputCls} value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })}>{subjects.slice(1).map((s) => <option key={s}>{s}</option>)}</select></Field>
        <Field label="Topic" error={err.topic}><input className={inputCls} value={form.topic} onChange={(e) => setForm({ ...form, topic: e.target.value })} /></Field>
        <div className="flex gap-2"><Btn onClick={save}>Add resource</Btn><Btn kind="ghost" onClick={() => setForm(null)}>Cancel</Btn></div></Card>)}
      <input className={inputCls + " mb-3"} placeholder="Search by title or topic" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search resources" />
      <select className={inputCls + " mb-3"} value={subj} onChange={(e) => setSubj(e.target.value)} aria-label="Filter by subject">{subjects.map((s) => <option key={s}>{s}</option>)}</select>
      <label className="flex items-center gap-2 text-sm mb-3"><input type="checkbox" checked={favOnly} onChange={(e) => setFavOnly(e.target.checked)} /> Show saved only</label>
      {list.length === 0 ? <Empty text="No resources found. Try a different subject or search." /> : list.map((r) => (
        <Card key={r.id} className="mb-2"><div className="flex justify-between gap-2"><div><div className="flex gap-2 mb-1"><Badge>{r.subject}</Badge><Badge color={C.navy}>{r.type}</Badge></div>
          <div className="font-semibold">{r.title}</div><div className="text-sm text-gray-500">{r.topic} · {r.by} · {fmt(r.date)}</div></div>
          <div className="flex flex-col gap-1">
            <button aria-label="Save resource" onClick={() => upd("resources", (x) => x.map((y) => y.id === r.id ? { ...y, fav: !y.fav } : y))} className="p-2"><Star size={22} color={C.teal} fill={r.fav ? C.teal : "none"} /></button>
            {isStaff && <button aria-label="Remove resource" onClick={() => { upd("resources", (x) => x.filter((y) => y.id !== r.id)); say("Resource removed"); }} className="p-2"><Trash2 size={20} color="#B3261E" /></button>}
          </div></div>
          <button className="text-sm font-semibold mt-2" style={{ color: C.teal }} onClick={() => say("Prototype: a real file link connects here")}>Open resource</button></Card>
      ))}
    </div>
  );
}

function Activities({ d, upd, say }) {
  const [cat, setCat] = useState("All"); const cats = ["All", ...new Set(seed.activities.map((a) => a.cat))];
  return (
    <div><Title>Student Activities</Title>
      <select className={inputCls + " mb-3"} value={cat} onChange={(e) => setCat(e.target.value)} aria-label="Filter activities">{cats.map((c) => <option key={c}>{c}</option>)}</select>
      {d.activities.filter((a) => cat === "All" || a.cat === cat).map((a) => (
        <Card key={a.id} className="mb-3"><Badge>{a.cat}</Badge><div className="font-semibold mt-1">{a.name}</div><p className="text-sm">{a.body}</p><p className="text-sm text-gray-500 mt-1">{a.when} · Contact: {a.staff}</p>
          <Btn className="mt-3" kind={a.interested ? "ghost" : "primary"} onClick={() => { upd("activities", (x) => x.map((y) => y.id === a.id ? { ...y, interested: !y.interested } : y)); say(a.interested ? "Interest removed" : "Interest sent. Staff will confirm your place."); }}>{a.interested ? "Interest sent ✓" : "Express interest"}</Btn></Card>
      ))}
    </div>
  );
}

function LostFound({ d, upd, say, isStaff }) {
  const [q, setQ] = useState(""); const [t, setT] = useState("All"); const [form, setForm] = useState(null); const [err, setErr] = useState({});
  const list = d.lostfound.filter((i) => (t === "All" || i.type === t) && (i.title + i.cat).toLowerCase().includes(q.toLowerCase()));
  const save = () => { const e = {}; if (form.title.trim().length < 3) e.title = "Enter the item name."; if (!form.place.trim()) e.place = "Enter a general area, such as Library."; if (form.body.trim().length < 5) e.body = "Add a short description. Do not include phone numbers or addresses."; setErr(e); if (Object.keys(e).length) return;
    upd("lostfound", (x) => [{ id: uid(), ...form, date: "2026-09-30", status: "Open" }, ...x]); say(`${form.type} report posted`); setForm(null); };
  return (
    <div>
      <Title right={<Btn onClick={() => setForm({ type: "Lost", title: "", cat: "Personal items", place: "", body: "" })}><Plus size={16} className="inline" /> Report</Btn>}>Lost & Found</Title>
      {form && (<Card className="mb-4">
        <Field label="Type"><select className={inputCls} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}><option>Lost</option><option>Found</option></select></Field>
        <Field label="Item name" error={err.title}><input className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></Field>
        <Field label="General area" error={err.place}><input className={inputCls} value={form.place} onChange={(e) => setForm({ ...form, place: e.target.value })} /></Field>
        <Field label="Description" error={err.body}><textarea rows={2} className={inputCls} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} /></Field>
        <div className="flex gap-2"><Btn onClick={save}>Post report</Btn><Btn kind="ghost" onClick={() => setForm(null)}>Cancel</Btn></div></Card>)}
      <input className={inputCls + " mb-3"} placeholder="Search items" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search items" />
      <div className="flex gap-2 mb-3">{["All", "Lost", "Found"].map((x) => <button key={x} onClick={() => setT(x)} className="rounded-full px-4 py-2 text-sm font-semibold border" style={{ background: t === x ? C.navy : "#fff", color: t === x ? "#fff" : C.navy, borderColor: C.navy }}>{x}</button>)}</div>
      {list.length === 0 ? <Empty text="Nothing here yet. Report an item to get started." /> : list.map((i) => (
        <Card key={i.id} className="mb-2"><div className="flex gap-2 mb-1"><Badge color={i.type === "Lost" ? "#B3261E" : C.green}>{i.type}</Badge><Badge color={C.navy}>{i.status}</Badge></div>
          <div className="font-semibold">{i.title}</div><div className="text-sm text-gray-500">{i.place} · {fmt(i.date)}</div><p className="text-sm">{i.body}</p>
          <p className="text-xs text-gray-500 mt-1">Collection is arranged through the main office.</p>
          {isStaff && <div className="flex gap-2 mt-2"><Btn kind="ghost" onClick={() => { upd("lostfound", (x) => x.map((y) => y.id === i.id ? { ...y, status: "Returned" } : y)); say("Marked as returned"); }}>Mark returned</Btn><Btn kind="danger" onClick={() => { upd("lostfound", (x) => x.filter((y) => y.id !== i.id)); say("Post removed"); }}>Remove</Btn></div>}</Card>
      ))}
    </div>
  );
}

function Tracker({ r }) {
  const step = STEP_OF[r.status]; const rej = r.status === "Rejected";
  return (
    <div className="mt-3">
      {STEPS.map((s, i) => {
        const done = i + 1 <= step && !(rej && i + 1 > 3);
        return (
          <div key={s} className="flex items-start gap-3 pb-3">
            <div className="flex flex-col items-center"><div className="w-6 h-6 rounded-full flex items-center justify-center text-white" style={{ background: done ? C.green : "#D1D5DB" }}>{done && <Check size={14} />}</div>{i < 5 && <div className="w-0.5 h-5" style={{ background: done ? C.green : "#D1D5DB" }} />}</div>
            <span className="text-sm" style={{ color: done ? C.text : "#9CA3AF", fontWeight: done ? 600 : 400 }}>{s}</span>
          </div>
        );
      })}
      {rej && <p className="text-sm font-semibold" style={{ color: "#B3261E" }}>This report was rejected after review.</p>}
      {r.updates.map((u, i) => <p key={i} className="text-sm border-l-4 pl-3 mb-2" style={{ borderColor: statusColor(u.status) }}><b>{u.status}</b> · {fmt(u.date)}: {u.msg}</p>)}
    </div>
  );
}

function Eco({ user, d, upd, say, isStaff, notify, tipIdx, setTipIdx }) {
  const [tab, setTab] = useState("dash"); const [openId, setOpenId] = useState(null);
  const tabs = [["dash", "Dashboard"], ["report", "Report"], ["mine", isStaff ? "Review" : "My reports"], ["sort", "Sorting guide"], ["events", "Eco-events"], ["challenges", "Challenges"]];
  const c = (s) => d.reports.filter((r) => r.status === s).length;
  const waiting = c("Pending") + c("Under Review");
  return (
    <div>
      <Title right={<Demo />}><span className="flex items-center gap-2" style={{ color: C.green }}><Leaf size={22} />EcoLink</span></Title>
      <div className="flex gap-2 overflow-x-auto pb-3">{tabs.map(([k, l]) => <button key={k} onClick={() => { setTab(k); setOpenId(null); }} className="whitespace-nowrap rounded-full px-3 py-2 text-sm font-semibold border" style={{ background: tab === k ? C.green : "#fff", color: tab === k ? "#fff" : C.green, borderColor: C.green }}>{l}</button>)}</div>

      {tab === "dash" && (<div>
        <div className="grid grid-cols-2 gap-3 mb-4">
          {[["Total reports", d.reports.length], ["Awaiting review", waiting], ["Being addressed", c("In Progress") + c("Approved")], ["Resolved", c("Resolved")]].map(([l, v]) => <Card key={l}><div className="text-3xl font-bold" style={{ color: C.green }}>{v}</div><div className="text-sm text-gray-500">{l}</div></Card>)}
        </div>
        <Card className="mb-4"><div className="font-semibold mb-2">Reports by status</div>
          {ECO_STATUSES.map((s) => <div key={s} className="flex items-center gap-2 mb-1 text-xs"><span className="w-24">{s}</span><div className="flex-1 bg-gray-100 rounded-full h-3"><div className="h-3 rounded-full" style={{ width: (d.reports.length ? (c(s) / d.reports.length) * 100 : 0) + "%", background: statusColor(s) }} /></div><span>{c(s)}</span></div>)}</Card>
        <Card className="mb-4"><div className="flex items-center gap-2 font-semibold mb-1"><Lightbulb size={18} color={C.green} />Eco tip</div><p className="text-sm mb-2">{TIPS[tipIdx % TIPS.length]}</p><Btn kind="ghost" onClick={() => setTipIdx(tipIdx + 1)}>Next tip</Btn></Card>
        <p className="text-sm">{d.ecoEvents.length} upcoming clean-up events · {d.challenges.length} active challenges</p>
      </div>)}

      {tab === "report" && <ReportForm user={user} upd={upd} say={say} onDone={() => setTab("mine")} notify={notify} />}

      {tab === "mine" && (() => {
        const list = isStaff ? d.reports : d.reports.filter((r) => r.by === user.id);
        if (list.length === 0) return <Empty text="You have no reports yet. Spot a problem? Use the Report tab." />;
        return list.map((r) => (
          <Card key={r.id} className="mb-3">
            <div className="flex justify-between"><Badge color={statusColor(r.status)}>{r.status}</Badge><span className="text-xs text-gray-500">{fmt(r.date)}</span></div>
            <div className="font-semibold mt-1">{r.title}</div><div className="text-sm text-gray-500">{r.cat} · {r.place}{r.assigned && " · Assigned: " + r.assigned}</div>
            <button className="text-sm font-semibold mt-2" style={{ color: C.green }} onClick={() => setOpenId(openId === r.id ? null : r.id)}>{openId === r.id ? "Hide tracker" : "Garbage-to-Action Tracker"}</button>
            {openId === r.id && <Tracker r={r} />}
            {isStaff && openId === r.id && <StaffUpdate r={r} upd={upd} say={say} notify={notify} />}
          </Card>
        ));
      })()}

      {tab === "sort" && <SortGuide />}

      {tab === "events" && d.ecoEvents.map((e) => (
        <Card key={e.id} className="mb-3"><Badge color={C.green}>Eco-event</Badge><div className="font-semibold mt-1">{e.title}</div><div className="text-sm text-gray-500">{fmt(e.date)} · {e.place} · {e.by}</div><p className="text-sm mt-1">{e.body}</p><p className="text-sm text-gray-500">How to take part: {e.how}</p>
          {!isStaff && <Btn className="mt-2" kind={e.interested ? "ghost" : "eco"} onClick={() => { upd("ecoEvents", (x) => x.map((y) => y.id === e.id ? { ...y, interested: !y.interested } : y)); say(e.interested ? "Interest removed" : "Interest sent. A teacher will supervise."); }}>{e.interested ? "Interested ✓" : "I'm interested"}</Btn>}</Card>
      ))}

      {tab === "challenges" && (<div>
        {isStaff && <NewChallenge upd={upd} say={say} />}
        {d.challenges.map((ch) => (
          <Card key={ch.id} className="mb-3"><div className="flex justify-between"><div className="font-semibold">{ch.title}</div><Trophy size={18} color={C.green} /></div><p className="text-sm">{ch.body}</p><p className="text-xs text-gray-500 mb-2">{fmt(ch.start)} – {fmt(ch.end)}</p>
            <div className="bg-gray-100 rounded-full h-3 mb-1"><div className="h-3 rounded-full" style={{ width: Math.min(100, (ch.progress / ch.goal) * 100) + "%", background: C.green }} /></div>
            <p className="text-xs mb-2">{ch.progress} of {ch.goal} days{ch.progress >= ch.goal ? " · Completed" : ""}</p>
            {!isStaff && (!ch.joined ? <Btn kind="eco" onClick={() => { upd("challenges", (x) => x.map((y) => y.id === ch.id ? { ...y, joined: true } : y)); say("You joined the challenge"); }}>Join challenge</Btn>
              : ch.progress < ch.goal && <Btn kind="ghost" onClick={() => { upd("challenges", (x) => x.map((y) => y.id === ch.id ? { ...y, progress: y.progress + 1 } : y)); say("Progress logged"); }}>Log today</Btn>)}</Card>
        ))}</div>)}
    </div>
  );
}

function ReportForm({ user, upd, say, onDone, notify }) {
  const cats = ["Overflowing garbage bins", "Littering", "Improper waste disposal", "Recycling issues", "Blocked drains", "Damaged bins", "Untidy school areas", "Other environmental concerns"];
  const [f, setF] = useState({ title: "", cat: cats[0], place: "", body: "" }); const [err, setErr] = useState({}); const [done, setDone] = useState(false);
  const submit = () => { const e = {}; if (f.title.trim().length < 5) e.title = "Enter a title of at least 5 characters."; if (!f.place.trim()) e.place = "Enter a general place, such as Block C or Canteen."; if (f.body.trim().length < 10) e.body = "Describe the problem in at least 10 characters."; setErr(e); if (Object.keys(e).length) return;
    upd("reports", (r) => [{ id: uid(), by: user.id, ...f, date: "2026-09-30", status: "Pending", assigned: "", updates: [] }, ...r]); notify(user.id, "Report received", f.title + " is now Pending.", "eco"); say("Report submitted"); setDone(true); };
  if (done) return <Card><div className="flex items-center gap-2 font-bold mb-2" style={{ color: C.green }}><Check />Report submitted</div><p className="text-sm mb-3">The school has received it. Follow every step in My reports.</p><Btn kind="eco" onClick={onDone}>Track my report</Btn></Card>;
  return (
    <Card>
      <Field label="Title" error={err.title}><input className={inputCls} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
      <Field label="Category"><select className={inputCls} value={f.cat} onChange={(e) => setF({ ...f, cat: e.target.value })}>{cats.map((c) => <option key={c}>{c}</option>)}</select></Field>
      <Field label="General school location" error={err.place}><input className={inputCls} value={f.place} onChange={(e) => setF({ ...f, place: e.target.value })} /></Field>
      <Field label="What did you see?" error={err.body}><textarea rows={3} className={inputCls} value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} /></Field>
      <p className="text-xs text-gray-500 mb-3">Do not approach hazards. Photo upload connects to secure storage in a live version.</p>
      <Btn kind="eco" onClick={submit}>Submit report</Btn>
    </Card>
  );
}

function StaffUpdate({ r, upd, say, notify }) {
  const [status, setStatus] = useState(r.status); const [msg, setMsg] = useState(""); const [who, setWho] = useState(r.assigned);
  const apply = () => { if (msg.trim().length < 5) { say("Add a short update message first"); return; }
    upd("reports", (x) => x.map((y) => y.id === r.id ? { ...y, status, assigned: who, updates: [...y.updates, { status, msg, date: "2026-09-30" }] } : y));
    notify(r.by, "Report update", `${r.title} is now ${status}.`, "eco"); say("Update saved and student notified"); setMsg(""); };
  return (
    <div className="mt-3 pt-3 border-t border-gray-200">
      <Field label="Status"><select className={inputCls} value={status} onChange={(e) => setStatus(e.target.value)}>{ECO_STATUSES.map((s) => <option key={s}>{s}</option>)}</select></Field>
      <Field label="Assign to"><input className={inputCls} value={who} placeholder="e.g. Caretaker" onChange={(e) => setWho(e.target.value)} /></Field>
      <Field label="Update for the student"><input className={inputCls} value={msg} onChange={(e) => setMsg(e.target.value)} /></Field>
      <Btn kind="eco" onClick={apply}>Save update</Btn>
    </div>
  );
}

function SortGuide() {
  const [q, setQ] = useState(""); const hit = q.trim() ? SORT.filter((s) => s.item.includes(q.toLowerCase())) : [];
  const cols = { Recyclable: C.teal, Organic: C.green, "General waste": "#6B7280", "Special disposal": "#B3261E" };
  return (
    <div>
      <input className={inputCls + " mb-3"} placeholder="Search an item, e.g. battery" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search waste item" />
      {q.trim() && hit.length === 0 && <Empty text="Item not listed. Ask a teacher or follow local authority instructions." />}
      {hit.map((s) => <Card key={s.item} className="mb-2"><Badge color={cols[s.bin]}>{s.bin}</Badge><div className="font-semibold capitalize mt-1">{s.item}</div><p className="text-sm">{s.why}</p></Card>)}
      {!q.trim() && Object.keys(cols).map((b) => (
        <Card key={b} className="mb-2"><div className="flex items-center gap-2 font-semibold mb-1"><Recycle size={18} color={cols[b]} />{b}</div><p className="text-sm text-gray-600 capitalize">{SORT.filter((s) => s.bin === b).map((s) => s.item).join(", ")}</p></Card>
      ))}
      <p className="text-xs text-gray-500 mt-2">Local waste rules vary. Always follow your school's and the local authority's instructions.</p>
    </div>
  );
}

function NewChallenge({ upd, say }) {
  const [t, setT] = useState("");
  return (
    <Card className="mb-3"><Field label="New eco-challenge title"><input className={inputCls} value={t} onChange={(e) => setT(e.target.value)} /></Field>
      <Btn kind="eco" onClick={() => { if (t.trim().length < 5) { say("Enter a title of at least 5 characters"); return; } upd("challenges", (x) => [...x, { id: uid(), title: t, body: "Supervised, safe school challenge.", start: "2026-09-30", end: "2026-10-14", goal: 5, progress: 0, joined: false }]); setT(""); say("Challenge created"); }}>Create challenge</Btn></Card>
  );
}

function Suggestions({ user, d, upd, say, isStaff, notify }) {
  const cats = ["Learning", "School facilities", "Technology", "Environment", "Events", "Student well-being", "Other"];
  const [f, setF] = useState({ title: "", cat: cats[0], body: "" }); const [err, setErr] = useState({}); const [reply, setReply] = useState({});
  const list = isStaff ? d.suggestions : d.suggestions.filter((s) => s.by === user.id);
  const submit = () => { const e = {}; if (f.title.trim().length < 5) e.title = "Enter a title of at least 5 characters."; if (f.body.trim().length < 10) e.body = "Explain your idea in at least 10 characters."; setErr(e); if (Object.keys(e).length) return;
    upd("suggestions", (s) => [{ id: uid(), by: user.id, ...f, status: "Submitted", reply: "", date: "2026-09-30" }, ...s]); setF({ title: "", cat: cats[0], body: "" }); say("Suggestion submitted. Staff will review it."); };
  const respond = (s, status) => { upd("suggestions", (x) => x.map((y) => y.id === s.id ? { ...y, status, reply: reply[s.id] || y.reply } : y)); notify(s.by, "Suggestion response", `${s.title}: ${status}`, "suggestions"); say("Response saved"); };
  return (
    <div><Title>Suggestions</Title>
      {!isStaff && (<Card className="mb-4"><Field label="Title" error={err.title}><input className={inputCls} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
        <Field label="Category"><select className={inputCls} value={f.cat} onChange={(e) => setF({ ...f, cat: e.target.value })}>{cats.map((c) => <option key={c}>{c}</option>)}</select></Field>
        <Field label="Your idea" error={err.body}><textarea rows={3} className={inputCls} value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })} /></Field>
        <p className="text-xs text-gray-500 mb-3">Every suggestion is reviewed. Not every idea can be used.</p><Btn onClick={submit}>Send suggestion</Btn></Card>)}
      {list.length === 0 ? <Empty text="No suggestions yet." /> : list.map((s) => (
        <Card key={s.id} className="mb-2"><div className="flex gap-2 mb-1"><Badge>{s.cat}</Badge><Badge color={C.navy}>{s.status}</Badge></div><div className="font-semibold">{s.title}</div><p className="text-sm">{s.body}</p>
          {s.reply && <p className="text-sm mt-2 p-2 rounded-lg" style={{ background: C.light }}><b>Staff reply:</b> {s.reply}</p>}
          {isStaff && (<div className="mt-3"><input className={inputCls + " mb-2"} placeholder="Write a reply" value={reply[s.id] || ""} onChange={(e) => setReply({ ...reply, [s.id]: e.target.value })} aria-label="Reply" />
            <div className="flex flex-wrap gap-2">{SG_STATUSES.slice(1).map((st) => <button key={st} onClick={() => respond(s, st)} className="text-xs font-semibold border rounded-full px-3 py-2" style={{ borderColor: C.navy, color: C.navy }}>{st}</button>)}</div></div>)}
        </Card>
      ))}
    </div>
  );
}

function Notifications({ notes, upd, go, say }) {
  const mark = (id) => upd("notifications", (n) => n.map((x) => x.id === id ? { ...x, read: true } : x));
  return (
    <div><Title right={notes.length > 0 && <Btn kind="ghost" onClick={() => { upd("notifications", (n) => n.map((x) => notes.some((m) => m.id === x.id) ? { ...x, read: true } : x)); say("All marked as read"); }}>Mark all read</Btn>}>Notifications</Title>
      {notes.length === 0 ? <Empty text="You're all caught up." /> : notes.map((n) => (
        <Card key={n.id} className="mb-2" onClick={() => { mark(n.id); go(n.page); }}>
          <div className="flex items-center gap-2">{!n.read && <span className="w-2 h-2 rounded-full" style={{ background: C.green }} />}<span className="font-semibold text-sm">{n.title}</span><span className="text-xs text-gray-500 ml-auto">{fmt(n.date)}</span></div><p className="text-sm text-gray-600">{n.msg}</p></Card>
      ))}
    </div>
  );
}

function Profile({ user, d, onOut, say, accounts, setAccounts }) {
  const [push, setPush] = useState(true); const [nick, setNick] = useState(user.name);
  const saved = d.resources.filter((r) => r.fav);
  return (
    <div><Title>Profile</Title>
      <Card className="mb-3"><div className="flex items-center gap-3 mb-3"><div className="w-14 h-14 rounded-full flex items-center justify-center text-white text-xl font-bold" style={{ background: C.teal }}>{nick[0]}</div><div><div className="font-bold">{nick}</div><div className="text-sm text-gray-500 capitalize">{user.role === "admin" ? "Administrator" : user.role} · {user.year}</div></div></div>
        <Field label="Display name"><input className={inputCls} value={nick} onChange={(e) => setNick(e.target.value)} /></Field>
        <label className="flex items-center gap-2 text-sm mb-3"><input type="checkbox" checked={push} onChange={(e) => setPush(e.target.checked)} /> In-app notifications</label>
        <Btn onClick={() => say(nick.trim() ? "Profile saved" : "Display name cannot be empty")}>Save changes</Btn></Card>
      <Card className="mb-3"><div className="font-semibold mb-1">Saved resources</div>{saved.length === 0 ? <p className="text-sm text-gray-500">Star a resource to save it here.</p> : saved.map((r) => <p key={r.id} className="text-sm">{r.title}</p>)}</Card>
      <ChangePw user={user} accounts={accounts} setAccounts={setAccounts} say={say} />
      <p className="text-xs text-gray-500 mb-3">Your contact details are never shown to other students.</p>
      <Btn kind="ghost" onClick={onOut}><LogOut size={16} className="inline mr-1" />Sign out</Btn>
    </div>
  );
}

function GlobalSearch({ d, user, isStaff, go }) {
  const [q, setQ] = useState(""); const t = q.trim().toLowerCase();
  const res = useMemo(() => {
    if (!t) return [];
    const m = (s) => s.toLowerCase().includes(t); const out = [];
    d.announcements.forEach((x) => m(x.title + x.body) && out.push(["Announcement", x.title, "announcements"]));
    d.events.forEach((x) => m(x.title + x.body) && out.push(["Event", x.title, "events"]));
    d.resources.forEach((x) => m(x.title + x.topic + x.subject) && out.push(["Resource", x.title, "resources"]));
    d.activities.forEach((x) => m(x.name + x.body) && out.push(["Activity", x.name, "activities"]));
    d.lostfound.forEach((x) => m(x.title + x.cat) && out.push(["Lost & Found", x.title, "lostfound"]));
    d.reports.filter((x) => isStaff || x.by === user.id).forEach((x) => m(x.title + x.cat) && out.push(["EcoLink report", x.title, "eco"]));
    TIPS.forEach((x) => m(x) && out.push(["Eco tip", x, "eco"]));
    return out;
  }, [t, d, isStaff, user]);
  return (
    <div><Title>Search</Title><input className={inputCls + " mb-3"} placeholder="Search everything" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Global search" />
      {t && res.length === 0 && <Empty text={`No results for "${q}". Try a shorter word.`} />}
      {res.map(([k, title, pg], i) => <Card key={i} className="mb-2" onClick={() => go(pg)}><Badge>{k}</Badge><div className="font-semibold text-sm mt-1">{title}</div></Card>)}
    </div>
  );
}

function Admin({ d, upd, say, isAdmin, accounts, setAccounts }) {
  const [nu, setNu] = useState({ name: "", role: "student", year: "" }); const [err, setErr] = useState({}); const [issued, setIssued] = useState(null);
  const eco = (st) => d.reports.filter((r) => r.status === st).length;
  const stats = [["Accounts", accounts.length], ["Announcements", d.announcements.length], ["Upcoming events", d.events.filter((e) => !e.cancelled).length], ["Resources", d.resources.length], ["Lost & Found posts", d.lostfound.length], ["EcoLink reports", d.reports.length], ["Suggestions", d.suggestions.length], ["Resolved eco reports", eco("Resolved")]];
  const temp = () => "Edu" + Math.floor(1000 + Math.random() * 9000) + "#";
  const create = () => {
    const e = {}; if (nu.name.trim().length < 2) e.name = "Enter a name."; if (!nu.year.trim()) e.year = nu.role === "student" ? "Enter the class, e.g. Form 3A." : "Enter a department or role.";
    setErr(e); if (Object.keys(e).length) return;
    const base = nu.name.trim().toLowerCase().replace(/[^a-z]+/g, ".").replace(/^\.|\.$/g, ""); let uname = base, n = 1;
    while (accounts.some((x) => x.username === uname + "@edulink.demo")) { n++; uname = base + n; }
    const pw = temp();
    setAccounts((x) => [...x, { id: uid(), username: uname + "@edulink.demo", password: pw, name: nu.name.trim().split(" ")[0], role: nu.role, year: nu.year.trim(), mustChange: true }]);
    setIssued({ username: uname + "@edulink.demo", password: pw }); setNu({ name: "", role: "student", year: "" }); say("Account created");
  };
  const reset = (acc) => { const pw = temp(); setAccounts((x) => x.map((y) => (y.id === acc.id ? { ...y, password: pw, mustChange: true } : y))); setIssued({ username: acc.username, password: pw }); say("Temporary password issued"); };
  return (
    <div><Title right={<Demo />}>{isAdmin ? "Admin Dashboard" : "Staff Dashboard"}</Title>
      <div className="grid grid-cols-2 gap-3 mb-4">{stats.map(([l, v]) => <Card key={l}><div className="text-2xl font-bold" style={{ color: C.navy }}>{v}</div><div className="text-xs text-gray-500">{l}</div></Card>)}</div>
      <Card className="mb-4"><div className="font-semibold mb-2">Moderation queue</div>
        {d.reports.filter((r) => r.status === "Pending").length === 0 ? <p className="text-sm text-gray-500">No pending eco reports.</p> : d.reports.filter((r) => r.status === "Pending").map((r) => <div key={r.id} className="flex items-center justify-between text-sm mb-2"><span>{r.title}</span><button className="font-semibold" style={{ color: C.green }} onClick={() => { upd("reports", (x) => x.map((y) => y.id === r.id ? { ...y, status: "Under Review", updates: [...y.updates, { status: "Under Review", msg: "Staff have started reviewing.", date: "2026-09-30" }] } : y)); say("Moved to Under Review"); }}>Start review</button></div>)}</Card>
      {isAdmin ? (<div>
        {issued && <Card className="mb-4"><div className="font-semibold mb-1" style={{ color: C.green }}>Share these details privately</div><p className="text-sm">Email: <b>{issued.username}</b></p><p className="text-sm mb-2">Temporary password: <b>{issued.password}</b></p><p className="text-xs text-gray-500 mb-2">They must choose a new password at first sign-in. This is shown once.</p><Btn kind="ghost" onClick={() => setIssued(null)}>Done</Btn></Card>}
        <Card className="mb-4"><div className="font-semibold mb-2">Create account</div>
          <Field label="Full name" error={err.name}><input className={inputCls} value={nu.name} onChange={(e) => setNu({ ...nu, name: e.target.value })} /></Field>
          <Field label="Role"><select className={inputCls} value={nu.role} onChange={(e) => setNu({ ...nu, role: e.target.value })}><option value="student">Student</option><option value="teacher">Teacher</option><option value="admin">Administrator</option></select></Field>
          <Field label={nu.role === "student" ? "Class" : "Department or role"} error={err.year}><input className={inputCls} value={nu.year} onChange={(e) => setNu({ ...nu, year: e.target.value })} /></Field>
          <Btn onClick={create}>Create account</Btn></Card>
        <Card><div className="font-semibold mb-2">Manage accounts</div>
          {accounts.map((u) => <div key={u.id} className="mb-3 pb-3 border-b border-gray-100 text-sm"><div className="flex items-center justify-between mb-1"><span><b>{u.name}</b> · {u.username}</span>
            <select className="border border-gray-300 rounded-lg px-2 py-2" value={u.role} onChange={(e) => { setAccounts((x) => x.map((y) => y.id === u.id ? { ...y, role: e.target.value } : y)); say("Role updated (demo)"); }} aria-label={"Role for " + u.name}><option value="student">Student</option><option value="teacher">Teacher</option><option value="admin">Administrator</option></select></div>
            <button className="text-xs font-semibold" style={{ color: C.teal }} onClick={() => reset(u)}>Reset password</button></div>)}
          <p className="text-xs text-gray-500">Prototype: passwords sit in memory in plain text. A live version uses a secure auth service that stores only hashed passwords and enforces roles on the server.</p></Card>
      </div>) : <p className="text-xs text-gray-500">Account management is available to administrators only.</p>}
    </div>
  );
}

function SchoolCalendar({ d, upd, say, isStaff, notify }) {
  const todayIso = "2026-09-30";
  const [type, setType] = useState("All"); const [form, setForm] = useState(null); const [err, setErr] = useState({});
  const [view, setView] = useState("Month"); const [sel, setSel] = useState(todayIso); const [month, setMonth] = useState(new Date(2026, 8, 1));
  const file = d.calFile;
  const range = (e) => fmt(e.start) + (e.end && e.end !== e.start ? " – " + fmt(e.end) : "");
  const isoOf = (t) => t.getFullYear() + "-" + String(t.getMonth() + 1).padStart(2, "0") + "-" + String(t.getDate()).padStart(2, "0");
  const addDays = (iso, n) => { const t = new Date(iso + "T00:00:00"); t.setDate(t.getDate() + n); return isoOf(t); };
  const monthOf = (iso) => new Date(+iso.slice(0, 4), +iso.slice(5, 7) - 1, 1);
  const onFile = (ev) => {
    if (!isStaff) { say("Only teachers and administrators can upload the calendar"); return; }
    const f = ev.target.files && ev.target.files[0]; if (!f) return;
    if (!["application/pdf", "image/png", "image/jpeg"].includes(f.type)) { say("Upload a PDF, PNG or JPG file"); ev.target.value = ""; return; }
    if (f.size > 5 * 1024 * 1024) { say("File must be under 5 MB"); ev.target.value = ""; return; }
    upd("calFile", () => ({ name: f.name, url: URL.createObjectURL(f), image: f.type !== "application/pdf", date: todayIso }));
    notify("s1", "School calendar updated", "The yearly school calendar was updated.", "calendar"); say("Calendar file uploaded"); ev.target.value = "";
  };
  const save = () => {
    const e = {}; if (form.title.trim().length < 3) e.title = "Enter a title of at least 3 characters.";
    if (!form.start) e.start = "Choose a start date."; if (form.end && form.start && form.end < form.start) e.end = "End date must be after the start date.";
    setErr(e); if (Object.keys(e).length) return;
    const item = { id: form.id || uid(), title: form.title.trim(), type: form.type, start: form.start, end: form.end };
    upd("calendar", (c) => (form.id ? c.map((x) => (x.id === form.id ? item : x)) : [...c, item]).sort((a, b) => a.start.localeCompare(b.start)));
    notify("s1", "School calendar updated", item.title, "calendar"); say(form.id ? "Calendar entry updated" : "Calendar entry added"); setForm(null);
  };
  const visible = d.calendar.filter((x) => type === "All" || x.type === type);
  const on = (iso) => visible.filter((x) => iso >= x.start && iso <= (x.end || x.start));
  const yr = month.getFullYear(), mo = month.getMonth();
  const lead = new Date(yr, mo, 1).getDay(); const dim = new Date(yr, mo + 1, 0).getDate();
  const cells = Array.from({ length: Math.ceil((lead + dim) / 7) * 7 }, (_, i) => { const t = new Date(yr, mo, 1 - lead + i); return { iso: isoOf(t), day: t.getDate(), out: t.getMonth() !== mo }; });
  const pick = (iso) => { setSel(iso); setMonth(monthOf(iso)); };
  const weekStart = addDays(sel, -new Date(sel + "T00:00:00").getDay());
  const shift = (n) => {
    if (view === "Month") setMonth(new Date(yr, mo + n, 1));
    else if (view === "Year") setMonth(new Date(yr + n, mo, 1));
    else { const nx = addDays(sel, view === "Week" ? 7 * n : n); pick(nx); }
  };
  const heading = view === "Year" ? String(yr) : view === "Day" ? new Date(sel + "T00:00:00").toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long" })
    : view === "Week" ? fmt(weekStart) + " – " + fmt(addDays(weekStart, 6)) : month.toLocaleDateString("en-GB", { month: "long", year: "numeric" });
  const Row = (x) => (
    <div key={x.id} className="flex gap-3 mb-3">
      <div className="w-14 text-xs text-gray-500 pt-1">All day</div>
      <div className="flex flex-col items-center"><span className="w-4 h-4 rounded-full" style={{ background: CAL_COLOR[x.type] }} /><span className="w-0.5 flex-1 bg-gray-200" /></div>
      <div className="flex-1"><div className="font-semibold text-sm">{x.title}</div><div className="text-xs text-gray-500">{x.type} · {range(x)}</div>
        {isStaff && <div className="flex gap-3 mt-1"><button className="text-xs font-semibold" style={{ color: C.teal }} onClick={() => { setErr({}); setForm({ ...x }); }}>Edit</button>
          <button className="text-xs font-semibold" style={{ color: "#B3261E" }} onClick={() => { upd("calendar", (c) => c.filter((y) => y.id !== x.id)); say("Calendar entry removed"); }}>Delete</button></div>}</div>
    </div>
  );
  const dayList = (iso) => { const items = on(iso); return items.length ? items.map(Row) : <p className="text-sm text-gray-400 mb-3 ml-1">Nothing scheduled</p>; };
  let lastM = "";
  return (
    <div>
      <Title right={isStaff && <Btn onClick={() => { setErr({}); setForm({ title: "", type: "Event", start: sel, end: "" }); }}><Plus size={16} className="inline" /> Add date</Btn>}>School Calendar</Title>
      <Card className="mb-4">
        <div className="font-semibold mb-1" style={{ color: C.navy }}>Yearly calendar file</div>
        {file ? (<div>
          {file.image && <img src={file.url} alt="School calendar" className="w-full rounded-xl mb-2" />}
          <p className="text-sm mb-2">{file.name} · updated {fmt(file.date)}</p>
          <a href={file.url} target="_blank" rel="noreferrer" className="text-sm font-semibold" style={{ color: C.teal }}>Open calendar file</a>
        </div>) : <p className="text-sm text-gray-500">No calendar file has been uploaded yet.</p>}
        {isStaff && (<div className="mt-3">
          <label className="block text-sm font-semibold mb-1" style={{ color: C.navy }}>{file ? "Replace calendar" : "Upload calendar"} (PDF, PNG or JPG, max 5 MB)</label>
          <input type="file" accept=".pdf,.png,.jpg,.jpeg" onChange={onFile} className="text-sm" />
          {file && <div className="mt-2"><Btn kind="danger" onClick={() => { upd("calFile", () => null); say("Calendar file removed"); }}>Remove file</Btn></div>}
          <p className="text-xs text-gray-500 mt-2">Prototype: the file is held in memory only. A live version stores it in secure cloud storage.</p>
        </div>)}
      </Card>
      {form && (<Card className="mb-4">
        <Field label="Title" error={err.title}><input className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></Field>
        <Field label="Type"><select className={inputCls} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>{CAL_TYPES.map((t) => <option key={t}>{t}</option>)}</select></Field>
        <Field label="Start date" error={err.start}><input type="date" className={inputCls} value={form.start} onChange={(e) => setForm({ ...form, start: e.target.value })} /></Field>
        <Field label="End date (optional)" error={err.end}><input type="date" className={inputCls} value={form.end} onChange={(e) => setForm({ ...form, end: e.target.value })} /></Field>
        <div className="flex gap-2"><Btn onClick={save}>{form.id ? "Save changes" : "Add to calendar"}</Btn><Btn kind="ghost" onClick={() => setForm(null)}>Cancel</Btn></div>
      </Card>)}
      <Card className="mb-4">
        <div className="flex justify-between border-b border-gray-100 pb-2 mb-3">
          {["Day", "Week", "Month", "Year", "Events"].map((v) => (
            <button key={v} onClick={() => setView(v)} className="px-2 py-2 text-sm font-semibold min-h-11" style={{ color: view === v ? C.teal : "#6B7280", borderBottom: view === v ? "3px solid " + C.teal : "3px solid transparent" }}>{v}</button>
          ))}
        </div>
        <div className="flex gap-2 overflow-x-auto pb-3">{["All", ...CAL_TYPES].map((t) => <button key={t} onClick={() => setType(t)} className="whitespace-nowrap rounded-full px-3 py-1 text-xs font-semibold border" style={{ background: type === t ? C.navy : "#fff", color: type === t ? "#fff" : C.navy, borderColor: C.navy }}>{t}</button>)}</div>

        {view !== "Events" && (
          <div className="flex items-center justify-between mb-2">
            <button aria-label="Previous" className="p-2" onClick={() => shift(-1)}><ChevronRight size={22} style={{ transform: "rotate(180deg)" }} /></button>
            <div className="font-bold text-center" style={{ color: C.navy }}>{heading}</div>
            <button aria-label="Next" className="p-2" onClick={() => shift(1)}><ChevronRight size={22} /></button>
          </div>
        )}

        {view === "Month" && (<div>
          <div className="grid grid-cols-7 mb-1">{["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((w) => <div key={w} className="text-center text-xs text-gray-500">{w}</div>)}</div>
          <div className="grid grid-cols-7">
            {cells.map((c) => {
              const items = on(c.iso); const isToday = c.iso === todayIso; const isSel = c.iso === sel;
              return (
                <button key={c.iso} onClick={() => pick(c.iso)} aria-label={c.iso + (items.length ? ", " + items.length + " entries" : "")} className="flex flex-col items-center py-1 min-h-12" style={{ opacity: c.out ? 0.4 : 1 }}>
                  <span className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-semibold" style={{ background: isToday ? C.teal : "transparent", color: isToday ? "#fff" : C.text, border: isSel && !isToday ? "2px solid " + C.teal : "2px solid transparent" }}>{c.day}</span>
                  <span className="flex gap-1 h-2">{items.slice(0, 3).map((x) => <span key={x.id} className="w-1.5 h-1.5 rounded-full" style={{ background: CAL_COLOR[x.type] }} />)}</span>
                </button>
              );
            })}
          </div>
        </div>)}

        {view === "Year" && (<div className="grid grid-cols-3 gap-2">
          {Array.from({ length: 12 }, (_, m) => {
            const n = visible.filter((x) => { const a = new Date(x.start + "T00:00:00"), b = new Date((x.end || x.start) + "T00:00:00"); return (a.getFullYear() < yr || (a.getFullYear() === yr && a.getMonth() <= m)) && (b.getFullYear() > yr || (b.getFullYear() === yr && b.getMonth() >= m)); }).length;
            return (<button key={m} onClick={() => { setMonth(new Date(yr, m, 1)); setSel(isoOf(new Date(yr, m, 1))); setView("Month"); }} className="rounded-xl py-4 border border-gray-200 flex flex-col items-center min-h-16">
              <span className="font-semibold text-sm" style={{ color: C.navy }}>{new Date(yr, m, 1).toLocaleDateString("en-GB", { month: "short" })}</span>
              <span className="text-xs mt-1" style={{ color: n ? C.teal : "#9CA3AF" }}>{n ? n + (n === 1 ? " entry" : " entries") : "None"}</span></button>);
          })}
        </div>)}
      </Card>

      {view === "Month" && (<div><h3 className="font-bold mb-3" style={{ color: C.navy }}>{sel === todayIso ? "Today" : fmt(sel)}</h3>{dayList(sel)}</div>)}
      {view === "Day" && dayList(sel)}
      {view === "Week" && Array.from({ length: 7 }, (_, i) => addDays(weekStart, i)).map((iso) => (
        <div key={iso}><h3 className="font-bold text-sm mb-2" style={{ color: iso === todayIso ? C.teal : C.navy }}>{new Date(iso + "T00:00:00").toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "short" })}</h3>{dayList(iso)}</div>
      ))}
      {view === "Events" && (visible.length === 0 ? <Empty text="No dates yet." /> : [...visible].sort((a, b) => a.start.localeCompare(b.start)).map((x) => {
        const m = new Date(x.start + "T00:00:00").toLocaleDateString("en-GB", { month: "long", year: "numeric" }); const head = m !== lastM; lastM = m;
        return <div key={x.id}>{head && <h3 className="text-sm font-bold mt-3 mb-2" style={{ color: C.teal }}>{m}</h3>}{Row(x)}</div>;
      }))}
      {view === "Year" && <p className="text-xs text-gray-500">Tap a month to open it.</p>}
    </div>
  );
}
